package com.qh.gcm.notify;

import com.qh.gcm.notify.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Screen extends Activity {
	TextView lblMessage;
	Intent intent;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activty_screen);
		
		/*
		 *
//********************************			
			//open new activity
			Intent myIntent = new Intent(context, Screen.class);
		    PendingIntent pendingIntent = PendingIntent.getActivity(
		    	      context, 
		    	      0, 
		    	      myIntent, 
		    	      Intent.FLAG_ACTIVITY_NEW_TASK);
		    
		    myNotification = new NotificationCompat.Builder(context)
		    		.setContentTitle("New Notification!")
		    		.setContentText(newMessage)
		    		.setTicker("Notification!")
		    		.setWhen(System.currentTimeMillis())
		    		.setContentIntent(pendingIntent)
		    		.setDefaults(Notification.DEFAULT_SOUND)
		    		.setAutoCancel(true)
		    		.setSmallIcon(R.drawable.gcm)
		    		.getNotification();
		    
		    notificationManager = 
		    		(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
		    notificationManager.notify(MY_NOTIFICATION_ID, myNotification);
//********************************
		    
		String newMessage = intent.getExtras().getString(EXTRA_MESSAGE);
		lblMessage = (TextView) findViewById(R.id.lblMessage);
		lblMessage.setText("Hello");			
		Toast.makeText(getApplicationContext(), "New Notification" + newMessage, Toast.LENGTH_LONG).show();
		*/
		
	}
	 
}
